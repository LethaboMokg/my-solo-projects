
import turtle as toy
import os

# players Scores being intialized

ping1 = 0
ping2 = 0

#created a tab for the window
#speed of the turtle(square)
tab = toy.Screen()   
tab.title("Lethabo's Ping Game") 
tab.bgcolor('grey')   
tab.setup(width = 800,height = 600) 
tab.tracer(0) 

# Created left wall 

left_wall = toy.Turtle()
left_wall.speed(0)
left_wall.shape('square')
left_wall.color('orange')
left_wall.shapesize(stretch_wid = 8,stretch_len = 1)
left_wall.penup()
left_wall.goto(-350,0)

# Created a right wall 

right_wall = toy.Turtle()
right_wall.speed(0)
right_wall.shape('square')
right_wall.shapesize(stretch_wid = 8,stretch_len = 1)
right_wall.color('orange')
right_wall.penup()
right_wall.goto(350,0)

# Created a ping ball 
#How the ball will move 
ping_ball = toy.Turtle()
ping_ball.speed(0)
ping_ball.shape('square')
ping_ball.color('pink')
ping_ball.penup()
ping_ball.goto(0,0)
ping_ball_xx = 1.6  
ping_ball_yy = 1.6

# updates the scores

pen = toy.Turtle()
pen.speed(0)
pen.color('orange')
pen.penup()
pen.hideturtle()
pen.goto(0,260)
pen.write("Ping 1: 0 Ping 2: 0 ", align = "center", font = ('Robo mono',25,"normal"))


# Moving the left wall using the keyboard

def left_wall_up():
    wall_y = left_wall.ycor()
    wall_y = wall_y + 15
    left_wall.sety(wall_y)

# Moving the left wall down

def left_wall_down():
    wall_y = left_wall.ycor()
    wall_y = wall_y - 15
    left_wall.sety(wall_y)

# Moving the right wall up

def right_wall_up():
    wall_y = right_wall.ycor()
    wall_y = wall_y + 15
    right_wall.sety(wall_y)

# Moving right wall down

def right_wall_down():
    wall_y = right_wall.ycor()
    wall_y = wall_y - 15
    right_wall.sety(wall_y)

# main keys/letters to press playing the game

tab.listen()
tab.onkeypress(left_wall_up,"z")
tab.onkeypress(left_wall_down,"c")
tab.onkeypress(right_wall_up,"Up")
tab.onkeypress(right_wall_down,"Down")

# Ping-pong Game starts
#updates the game to function
#setting a border for the game

while True:
    
    tab.update()

    # Moving the ball
    ping_ball.setx(ping_ball.xcor() + ping_ball_xx)
    ping_ball.sety(ping_ball.ycor() + ping_ball_yy)

    # Right top wall 
    if ping_ball.ycor() > 290:  
        ping_ball.sety(290)
        ping_ball_yy = ping_ball_yy * -1
        
     # Left top wall 
    if ping_ball.ycor() < -290: 
        ping_ball.sety(-290)
        ping_ball_yy = ping_ball_yy * -1
        
      # right width wall 
    if ping_ball.xcor() > 390: 
        ping_ball.goto(0,0)
        ping_ball_xx = ping_ball_xx * -1
        ping1 = ping1+ 1
        pen.clear()
        pen.write("Ping 1: {} Ping  2: {} ".format(ping1,ping1), align = "center", font = ('Robo mono',25,"normal"))
        os.system("afplay wallhit.wav&")


    # Left width wall 
    if(ping_ball.xcor()) < -390:
        ping_ball.goto(0,0)
        ping_ball_xx = ping_ball_xx * -1
        ping2 = ping2 + 1
        pen.clear()
        pen.write("Ping 1: {}   Ping 2: {} ".format(ping2,ping2), align = "center", font = ('Robo mono',25,"normal"))
        os.system("afplay wallhit.wav&")


    #How the ball is functioning
    if(ping_ball.xcor() > 370) and (ping_ball.xcor() < 380) and (ping_ball.ycor() < right_wall.ycor() + 50 and ping_ball.ycor() > right_wall.ycor() - 50):
        ping_ball.setx(370)
        ping_ball_xx = ping_ball_xx * -1
        os.system("afplay paddle.wav&")

    if(ping_ball.xcor() < -370) and (ping_ball.xcor() > -380) and (ping_ball.ycor() < left_wall.ycor() + 50 and ping_ball.ycor() > left_wall.ycor() - 50):
        ping_ball.setx(-370)
        ping_ball_xx = ping_ball_xx * -1
        os.system("afplay paddle.wav&")

